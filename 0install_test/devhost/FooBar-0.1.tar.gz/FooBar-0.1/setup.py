#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

from distutils.core import setup
from FooBar import __version__

if 'install' in sys.argv or 'develop' in sys.argv:
  print("FooBar {version}".format(version=__version__))

setup(name='FooBar', packages=['FooBar'], version=__version__)

